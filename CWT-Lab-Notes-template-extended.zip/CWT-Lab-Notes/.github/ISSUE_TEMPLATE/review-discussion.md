---
name: Paper Review Discussion
about: Start a discussion on a reviewed paper
title: "[Review] "
labels: []
assignees: []
---

## 📄 Paper
- Title:
- Link:
- Group/Semester:

## 💡 Summary

## ❓ Discussion Points

